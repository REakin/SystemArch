import connexion
from connexion import NoContent
from requests import request


from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from base import Base
from Region import Region
from Roast import Roast


import datetime

#db setup

DB_ENGINE = create_engine('sqlite:///readings.sqlite')
Base.metadata.bind = DB_ENGINE
DB_SESSION = sessionmaker(bind=DB_ENGINE)

#Your functions here

def addRegion(cofRegion):
    print(cofRegion)
    session = DB_SESSION()
    region = Region(cofRegion['id'],
                    cofRegion['name'])
    session.add(region)
    session.commit()
    session.close()
    return NoContent, 201

def getRegion(searchStringstart,searchStringend ):
    results_list = []

    session = DB_SESSION()

    results = []

    results = session.query(Region).filter(Region.date_created >= searchStringstart, Region.date_created <= searchStringend)

    for result in results:
        results_list.append(result.to_dict())
        print(result.to_dict())
    session.close()

    return results_list, 200

def addRoast(roastType):
    print(roastType)
    session = DB_SESSION()
    roast = Roast(roastType['name'],
                  roastType['region'])
    session.add(roast)
    session.commit()
    session.close()
    return NoContent, 201


def getRoast(searchStingstart, searchStringend):
    results_list = []

    session = DB_SESSION()

    results = []

    results = session.query(Roast).filter(Roast.date_created >= searchStingstart, Roast.date_created <= searchStringend)

    for result in results:
        results_list.append(result.to_dict())
        print(result.to_dict())
    session.close()

    return results_list, 200




#my fucntiosn end here :)

app = connexion.FlaskApp(__name__, specification_dir='')
app.add_api("openapi.yaml")

if __name__ == "__main__":
    app.run(port=8090, debug=True)