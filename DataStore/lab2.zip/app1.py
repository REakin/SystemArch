import connexion
import json
from connexion import NoContent
import requests

from Region import Region
from Roast import Roast

import datetime

#Your functions here

def addRegion(cofRegion):
    requests.post('http://localhost:8090/coffee/region',json=json.dumps(cofRegion), headers={'content-type':'application/json'})
    return NoContent, requests.status_codes


def addRoast(roastType):
    requests.post('http://localhost8090/coffee/roast',json=json.dumps(roastType), headers={'content-type':'application/json'})
    return NoContent, requests.status_codes


#my fucntiosn end here :)

app = connexion.FlaskApp(__name__, specification_dir='')
app.add_api("openapi.yaml")

if __name__ == "__main__":
    app.run(port=8080, debug=True)